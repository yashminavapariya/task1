import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import AddUserForm from './Components/AddUserForm';


function App() {
  return (
    <div className="App">
      <AddUserForm />
    </div>
  );
}
export default App;